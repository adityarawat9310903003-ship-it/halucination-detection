"""Fast tests for the pure logic (no model downloads needed)."""
import pytest

from hybrid_detector import classifier as C
from hybrid_detector.config import Config
from hybrid_detector.expert import parse_verdict
from hybrid_detector.qa import candidate_answers
from hybrid_detector.utils import split_sentences, token_f1, weighted

cfg = Config()


def test_weighted_skips_missing_and_renormalises():
    assert weighted([(1.0, 0.7), (None, 0.3)]) == pytest.approx(1.0)
    assert weighted([(1.0, 0.5), (0.0, 0.5)]) == pytest.approx(0.5)
    assert weighted([(None, 1.0)]) is None


def test_token_f1():
    assert token_f1("Paris", "paris") == 1.0
    assert token_f1("Paris", "Berlin") == 0.0
    assert 0 < token_f1("the Eiffel Tower", "Eiffel") < 1


def test_split_sentences():
    assert split_sentences("Paris is in France. It is big.") == ["Paris is in France.", "It is big."]


def test_candidate_answers():
    spans = candidate_answers("Marie Curie won a prize in 1903.", 3)
    assert "Marie Curie" in spans and "1903" in spans


@pytest.mark.parametrize("grounding,veracity,expected", [
    (0.9, 0.9, C.SUPPORTED),
    (0.1, 0.9, C.UNSUPPORTED),
    (0.9, 0.1, C.CONTRADICTED),
    (0.1, 0.1, C.HALLUCINATED),
])
def test_2d_classification(grounding, veracity, expected):
    assert C.classify(cfg, grounding, veracity) == expected


def test_nli_scores():
    entail = {"entailment": 0.95, "neutral": 0.03, "contradiction": 0.02}
    contra = {"entailment": 0.02, "neutral": 0.03, "contradiction": 0.95}
    neutral = {"entailment": 0.05, "neutral": 0.9, "contradiction": 0.05}
    assert C.nli_truth(entail) > 0.9 and C.nli_truth(contra) < 0.1
    assert C.nli_truth(neutral) == pytest.approx(0.5)
    assert C.nli_coverage(neutral) < 0.2 and C.nli_coverage(contra) > 0.9


def test_contradicted_when_source_disagrees():
    contra = {"entailment": 0.02, "neutral": 0.03, "contradiction": 0.95}
    g = C.grounding_score(cfg, contra, None)
    v = C.veracity_score(cfg, contra, None, None)
    assert C.classify(cfg, g, v) == C.CONTRADICTED


def test_expert_override_drops_veracity():
    assert C.apply_expert(cfg, 0.6, "false") == pytest.approx(0.12)
    assert C.apply_expert(cfg, 0.6, "true") == 0.6
    assert C.in_expert_band(cfg, 0.5) and not C.in_expert_band(cfg, 0.9)


def test_parse_verdict_handles_messy_output():
    messy = 'Sure!\n```json\n{"verdict": "FALSE", "confidence": 0.9, "reason": "x"}\n```'
    assert parse_verdict(messy)["verdict"] == "false"
    assert parse_verdict("no json here")["verdict"] == "uncertain"
    assert parse_verdict('{"verdict": "maybe"}')["verdict"] == "uncertain"
