"""Signal 3: sampling-based self-consistency (SelfCheckGPT style).

Sample several answers about the claim's subject; a claim the model keeps
reproducing is more likely to be true than one it only 'guesses' once.
"""
from typing import Optional


class SelfConsistency:
    def __init__(self, groq, nli, n_samples: int = 5):
        self.groq, self.nli, self.n = groq, nli, n_samples

    def score(self, claim: str, topic: Optional[str] = None) -> Optional[float]:
        if not self.groq.available:
            return None
        prompt = topic or f"Write two or three factual sentences about the subject of this statement: {claim}"
        samples = self.groq.sample(prompt, self.n)
        if not samples:
            return None
        ent = [self.nli.probs(s, claim)["entailment"] for s in samples]
        return sum(ent) / len(ent)
