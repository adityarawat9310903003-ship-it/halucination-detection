"""Signal 1: Natural Language Inference (RoBERTa MNLI)."""


class NLIModel:
    def __init__(self, model_name: str):
        import torch
        from transformers import AutoModelForSequenceClassification, AutoTokenizer

        self.torch = torch
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        self.model = AutoModelForSequenceClassification.from_pretrained(model_name).to(self.device).eval()
        # Map model-specific label names to our canonical keys.
        self.idx = {}
        for i, name in self.model.config.id2label.items():
            n = name.lower()
            if n.startswith("entail"):
                self.idx["entailment"] = int(i)
            elif n.startswith("neutral"):
                self.idx["neutral"] = int(i)
            elif n.startswith("contra"):
                self.idx["contradiction"] = int(i)

    def probs(self, premise: str, hypothesis: str) -> dict:
        """P(entailment / neutral / contradiction) of `hypothesis` given `premise`."""
        enc = self.tokenizer(premise, hypothesis, truncation=True, max_length=512,
                             return_tensors="pt").to(self.device)
        with self.torch.no_grad():
            p = self.torch.softmax(self.model(**enc).logits, dim=-1)[0].tolist()
        return {k: p[i] for k, i in self.idx.items()}
