"""Small dependency-free helpers (kept torch-free so they are easy to test)."""
import re
import string
from collections import Counter

_SENT_RE = re.compile(r"(?<=[.!?])\s+(?=[A-Z0-9\"'])")
_ARTICLES = {"a", "an", "the"}


def split_sentences(text: str) -> list:
    """Naive sentence splitter: each sentence is treated as one claim."""
    return [s.strip() for s in _SENT_RE.split(text.strip()) if s.strip()]


def normalize(text: str) -> list:
    text = text.lower().translate(str.maketrans("", "", string.punctuation))
    return [t for t in text.split() if t not in _ARTICLES]


def token_f1(a: str, b: str) -> float:
    """SQuAD-style token F1 between two answer strings."""
    ta, tb = normalize(a), normalize(b)
    if not ta or not tb:
        return 1.0 if ta == tb else 0.0
    common = Counter(ta) & Counter(tb)
    overlap = sum(common.values())
    if overlap == 0:
        return 0.0
    p, r = overlap / len(tb), overlap / len(ta)
    return 2 * p * r / (p + r)


def weighted(parts):
    """Weighted mean over (value, weight) pairs, skipping missing (None) signals
    and renormalising the remaining weights. Returns None if nothing is available."""
    num = den = 0.0
    for value, weight in parts:
        if value is None:
            continue
        num += value * weight
        den += weight
    return None if den == 0 else num / den


def clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))
