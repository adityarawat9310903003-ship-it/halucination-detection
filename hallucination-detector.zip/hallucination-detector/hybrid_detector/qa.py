"""Signal 2: QAGS-style question generation / answering.

For each answer-like span in the claim we generate a question, answer it against
the source, and compare with the span from the claim.
  coverage    -> did the source contain an answer at all? (used for Grounding)
  consistency -> does the source answer match the claim's span? (used for Veracity)
"""
import re
from typing import Optional, Tuple

from .utils import token_f1

# Candidate answer spans: runs of capitalised words, or numbers.
_SPAN_RE = re.compile(r"\b(?:[A-Z][\w'\-]*(?:\s+[A-Z][\w'\-]*)*|\d[\d,]*(?:\.\d+)?%?)")
_STOP = {"The", "A", "An", "It", "He", "She", "They", "This", "That", "In", "On", "At"}


def candidate_answers(claim: str, limit: int) -> list:
    seen, out = set(), []
    for m in _SPAN_RE.finditer(claim):
        span = m.group(0).strip()
        if span in _STOP or span.lower() in seen:
            continue
        seen.add(span.lower())
        out.append(span)
        if len(out) >= limit:
            break
    return out


class QAGS:
    def __init__(self, qg_model: str, qa_model: str, max_questions: int = 3, max_context_chars: int = 3000):
        import torch
        from transformers import AutoModelForSeq2SeqLM, AutoTokenizer, pipeline

        self.torch = torch
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        self.max_questions = max_questions
        self.max_context_chars = max_context_chars
        self.qg_tok = AutoTokenizer.from_pretrained(qg_model)
        self.qg = AutoModelForSeq2SeqLM.from_pretrained(qg_model).to(self.device).eval()
        self.qa = pipeline("question-answering", model=qa_model,
                           device=0 if self.device == "cuda" else -1)

    def _question(self, claim: str, answer: str) -> str:
        highlighted = claim.replace(answer, f"<hl> {answer} <hl>", 1)
        enc = self.qg_tok("generate question: " + highlighted, return_tensors="pt",
                          truncation=True, max_length=512).to(self.device)
        with self.torch.no_grad():
            out = self.qg.generate(**enc, max_length=64, num_beams=4)
        return self.qg_tok.decode(out[0], skip_special_tokens=True)

    def _answer(self, question: str, context: str) -> str:
        res = self.qa(question=question, context=context[: self.max_context_chars],
                      handle_impossible_answer=True)
        return (res.get("answer") or "").strip()

    def score(self, claim: str, source: str) -> Tuple[Optional[float], Optional[float]]:
        """Returns (coverage, consistency), or (None, None) if no question could be built.
        Wrapped defensively: generative extraction is the brittle part of QAGS."""
        try:
            spans = candidate_answers(claim, self.max_questions)
            if not spans:
                return None, None
            covered, f1s = 0, []
            for span in spans:
                q = self._question(claim, span)
                if not q.strip():
                    continue
                ans = self._answer(q, source)
                if ans:
                    covered += 1
                f1s.append(token_f1(span, ans) if ans else 0.0)
            if not f1s:
                return None, None
            return covered / len(f1s), sum(f1s) / len(f1s)
        except Exception:
            return None, None
