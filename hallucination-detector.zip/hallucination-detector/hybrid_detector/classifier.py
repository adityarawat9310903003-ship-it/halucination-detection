"""The 2D classification engine (pure functions, no model dependencies).

Grounding : is the claim addressed by / aligned with the source?
Veracity  : is the claim factually true?

                      grounded            not grounded
   true               SUPPORTED           UNSUPPORTED
   false              CONTRADICTED        HALLUCINATED
"""
from typing import Optional

from .config import Config
from .utils import clamp, weighted

SUPPORTED, UNSUPPORTED, CONTRADICTED, HALLUCINATED = (
    "Supported", "Unsupported", "Contradicted", "Hallucinated")


def nli_truth(p: dict) -> float:
    """Entailment pushes toward 1, contradiction toward 0, neutral stays at 0.5."""
    return clamp(0.5 + 0.5 * (p["entailment"] - p["contradiction"]))


def nli_coverage(p: dict) -> float:
    """How strongly the source takes a stance (entails OR contradicts) on the claim."""
    return clamp(1.0 - p["neutral"])


def grounding_score(cfg: Config, nli_p: dict, qa_coverage: Optional[float]) -> float:
    return weighted([(nli_coverage(nli_p), cfg.g_nli), (qa_coverage, cfg.g_qa)])


def veracity_score(cfg: Config, nli_p: dict, qa_consistency: Optional[float], sc: Optional[float]) -> float:
    return weighted([(nli_truth(nli_p), cfg.v_agree), (qa_consistency, cfg.v_qa), (sc, cfg.v_sc)])


def fused_score(cfg: Config, nli_p: dict, qa_consistency: Optional[float], sc: Optional[float]) -> float:
    """Single hybrid support score (40% NLI / 40% QA / 20% SC) used for baseline comparison."""
    return weighted([(nli_p["entailment"], cfg.f_nli), (qa_consistency, cfg.f_qa), (sc, cfg.f_sc)])


def in_expert_band(cfg: Config, veracity: float) -> bool:
    lo, hi = cfg.expert_band
    return lo <= veracity <= hi


def apply_expert(cfg: Config, veracity: float, verdict: str) -> float:
    """A spotted contradiction drops veracity harshly, overriding the local rules."""
    if verdict == "false":
        return veracity * cfg.expert_penalty
    return veracity


def classify(cfg: Config, grounding: float, veracity: float) -> str:
    grounded = grounding >= cfg.threshold
    true = veracity >= cfg.threshold
    if true and grounded:
        return SUPPORTED
    if true:
        return UNSUPPORTED
    if grounded:
        return CONTRADICTED
    return HALLUCINATED
