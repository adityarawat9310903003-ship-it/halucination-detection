"""Evidence retrieval: MiniLM embeddings + NLI-based reranking."""


class Retriever:
    def __init__(self, embed_model: str, nli, k: int = 5):
        from sentence_transformers import SentenceTransformer, util

        self.util = util
        self.model = SentenceTransformer(embed_model)
        self.nli, self.k = nli, k

    def retrieve(self, claim: str, docs: list) -> list:
        docs = [d for d in docs if d and d.strip()]
        if len(docs) <= 1:
            return docs
        q = self.model.encode(claim, convert_to_tensor=True)
        d = self.model.encode(docs, convert_to_tensor=True)
        sims = self.util.cos_sim(q, d)[0].tolist()
        # 1) semantic shortlist (2k) with embeddings
        shortlist = sorted(range(len(docs)), key=lambda i: sims[i], reverse=True)[: self.k * 2]
        # 2) rerank by logical relevance: documents that entail OR contradict the
        #    claim are relevant; neutral ones are merely topically similar.
        def logical_relevance(i):
            p = self.nli.probs(docs[i], claim)
            return 1.0 - p["neutral"]
        reranked = sorted(shortlist, key=logical_relevance, reverse=True)[: self.k]
        return [docs[i] for i in reranked]
