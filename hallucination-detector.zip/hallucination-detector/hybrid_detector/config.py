"""Central configuration: model names, signal weights and thresholds.

Weights follow the project report:
  Grounding = 70% NLI + 30% QA
  Veracity  = 50% model agreement + 30% QA consistency + 20% sampling (self-consistency)
  Fused hybrid score (used for baseline comparison) = 40% NLI + 40% QA + 20% SC
"""
import os
from dataclasses import dataclass, field


@dataclass
class Config:
    # --- models ---
    nli_model: str = "roberta-large-mnli"
    qa_model: str = "deepset/roberta-base-squad2"
    qg_model: str = "valhalla/t5-base-qg-hl"
    embed_model: str = "sentence-transformers/all-MiniLM-L6-v2"
    groq_model: str = "llama-3.3-70b-versatile"
    groq_api_key: str = field(default_factory=lambda: os.getenv("GROQ_API_KEY", ""))

    # --- retrieval ---
    retrieval_k: int = 5

    # --- signals ---
    n_samples: int = 5          # self-consistency generations
    max_questions: int = 3      # QAGS questions per claim
    max_context_chars: int = 3000  # safety bound for QA inference

    # --- 2D score weights ---
    g_nli: float = 0.7
    g_qa: float = 0.3
    v_agree: float = 0.5
    v_qa: float = 0.3
    v_sc: float = 0.2

    # --- fused hybrid score (baseline comparison) ---
    f_nli: float = 0.4
    f_qa: float = 0.4
    f_sc: float = 0.2

    # --- control flow ---
    shortcircuit_threshold: float = 0.90   # NLI confident -> skip QA / SC
    expert_band: tuple = (0.35, 0.65)      # ambiguous veracity -> ask the expert
    expert_penalty: float = 0.20           # veracity multiplier on expert "false"
    threshold: float = 0.50                # grounded / true cut-off
