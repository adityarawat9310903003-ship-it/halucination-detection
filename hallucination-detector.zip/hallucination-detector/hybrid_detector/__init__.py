"""Hybrid 2D Hallucination Detector (Veracity x Grounding)."""
from .config import Config
from .pipeline import Detector, ClaimResult

__all__ = ["Config", "Detector", "ClaimResult"]
__version__ = "0.1.0"
