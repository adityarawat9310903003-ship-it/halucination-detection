"""Expert validation layer: Llama-3 70B through the Groq SDK.

Also provides the sampler used by the self-consistency signal.
"""
import json
import re
from typing import Optional

JUDGE_SYSTEM = (
    "You are a strict fact-checking expert. Given a CLAIM and optional EVIDENCE, decide "
    "whether the claim is factually true in the real world. Respond with ONLY a JSON object: "
    '{"verdict": "true" | "false" | "uncertain", "confidence": <0..1>, "reason": "<short>"}'
)


def parse_verdict(text: str) -> dict:
    """Robustly parse the model output (strip code fences / extra prose)."""
    default = {"verdict": "uncertain", "confidence": 0.0, "reason": ""}
    if not text:
        return default
    m = re.search(r"\{.*\}", text, re.S)
    if not m:
        return default
    try:
        data = json.loads(m.group(0))
    except json.JSONDecodeError:
        return default
    verdict = str(data.get("verdict", "uncertain")).strip().lower()
    if verdict not in {"true", "false", "uncertain"}:
        verdict = "uncertain"
    try:
        conf = max(0.0, min(1.0, float(data.get("confidence", 0.0))))
    except (TypeError, ValueError):
        conf = 0.0
    return {"verdict": verdict, "confidence": conf, "reason": str(data.get("reason", ""))[:300]}


class GroqClient:
    def __init__(self, api_key: str, model: str):
        self.model = model
        self._client = None
        if api_key:
            try:
                from groq import Groq
                self._client = Groq(api_key=api_key)
            except ImportError:
                pass

    @property
    def available(self) -> bool:
        return self._client is not None

    def _chat(self, messages, temperature: float, max_tokens: int = 300) -> str:
        resp = self._client.chat.completions.create(
            model=self.model, messages=messages, temperature=temperature, max_tokens=max_tokens)
        return resp.choices[0].message.content or ""

    def sample(self, prompt: str, n: int, temperature: float = 1.0) -> list:
        """n stochastic generations for self-consistency checking."""
        if not self.available:
            return []
        out = []
        for _ in range(n):
            try:
                out.append(self._chat([{"role": "user", "content": prompt}], temperature))
            except Exception:
                continue
        return out

    def judge(self, claim: str, evidence: Optional[str] = None) -> dict:
        if not self.available:
            return {"verdict": "uncertain", "confidence": 0.0, "reason": "expert unavailable"}
        user = f"CLAIM: {claim}\n\nEVIDENCE: {evidence or '(none)'}"
        try:
            text = self._chat([{"role": "system", "content": JUDGE_SYSTEM},
                               {"role": "user", "content": user}], temperature=0.0)
        except Exception as e:
            return {"verdict": "uncertain", "confidence": 0.0, "reason": f"error: {e}"}
        return parse_verdict(text)
