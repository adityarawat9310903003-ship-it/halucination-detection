"""End-to-end detector: retrieve -> NLI -> (QA + SC) -> expert -> 2D label."""
from dataclasses import asdict, dataclass, field
from typing import List, Optional

from . import classifier as C
from .config import Config
from .utils import split_sentences


@dataclass
class ClaimResult:
    claim: str
    label: str
    grounding: float
    veracity: float
    fused: float
    nli: dict
    qa_coverage: Optional[float] = None
    qa_consistency: Optional[float] = None
    self_consistency: Optional[float] = None
    short_circuited: bool = False
    expert: Optional[dict] = None
    evidence: List[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return asdict(self)


class Detector:
    """Models are loaded lazily so cheap parts (and tests) never pull in torch."""

    def __init__(self, cfg: Optional[Config] = None):
        self.cfg = cfg or Config()
        self._nli = self._qa = self._groq = self._sc = self._retriever = None

    # ---- lazy components ----
    @property
    def nli(self):
        if self._nli is None:
            from .nli import NLIModel
            self._nli = NLIModel(self.cfg.nli_model)
        return self._nli

    @property
    def qa(self):
        if self._qa is None:
            from .qa import QAGS
            self._qa = QAGS(self.cfg.qg_model, self.cfg.qa_model,
                            self.cfg.max_questions, self.cfg.max_context_chars)
        return self._qa

    @property
    def groq(self):
        if self._groq is None:
            from .expert import GroqClient
            self._groq = GroqClient(self.cfg.groq_api_key, self.cfg.groq_model)
        return self._groq

    @property
    def sc(self):
        if self._sc is None:
            from .consistency import SelfConsistency
            self._sc = SelfConsistency(self.groq, self.nli, self.cfg.n_samples)
        return self._sc

    @property
    def retriever(self):
        if self._retriever is None:
            from .retrieval import Retriever
            self._retriever = Retriever(self.cfg.embed_model, self.nli, self.cfg.retrieval_k)
        return self._retriever

    # ---- public API ----
    def verify_claim(self, claim: str, documents: List[str], topic: Optional[str] = None,
                     short_circuit: bool = True, use_expert: bool = True) -> ClaimResult:
        cfg = self.cfg
        evidence = self.retriever.retrieve(claim, documents)
        source = " ".join(evidence)
        nli_p = self.nli.probs(source, claim) if source else {"entailment": 0.0, "neutral": 1.0, "contradiction": 0.0}

        confident = max(nli_p["entailment"], nli_p["contradiction"]) >= cfg.shortcircuit_threshold
        skip = short_circuit and confident          # NLI short-circuit: skip QA + SC

        qa_cov = qa_con = sc = None
        if not skip and source:
            qa_cov, qa_con = self.qa.score(claim, source)
            sc = self.sc.score(claim, topic)

        grounding = C.grounding_score(cfg, nli_p, qa_cov)
        veracity = C.veracity_score(cfg, nli_p, qa_con, sc)
        fused = C.fused_score(cfg, nli_p, qa_con, sc)

        expert = None
        if use_expert and self.groq.available and (not skip) and C.in_expert_band(cfg, veracity):
            expert = self.groq.judge(claim, source)
            veracity = C.apply_expert(cfg, veracity, expert["verdict"])

        return ClaimResult(
            claim=claim, label=C.classify(cfg, grounding, veracity),
            grounding=round(grounding, 4), veracity=round(veracity, 4), fused=round(fused, 4),
            nli={k: round(v, 4) for k, v in nli_p.items()},
            qa_coverage=qa_cov, qa_consistency=qa_con, self_consistency=sc,
            short_circuited=skip, expert=expert, evidence=evidence)

    def verify_text(self, text: str, documents: List[str], topic: Optional[str] = None) -> List[ClaimResult]:
        """Sentence-level verification of a whole LLM response."""
        return [self.verify_claim(s, documents, topic) for s in split_sentences(text)]
